package com.sistema.service;

import com.sistema.dto.EquipamentoDTO;
import com.sistema.model.Equipamento;
import com.sistema.repository.EquipamentoRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class EquipamentoService {
    private final EquipamentoRepository equipamentoRepository;

    public EquipamentoService() {
        this.equipamentoRepository = new EquipamentoRepository();
    }

    // Listar todos os equipamentos em formato DTO
    public List<EquipamentoDTO> getAllEquipamentos() throws SQLException {
        List<Equipamento> equipamentos = equipamentoRepository.findAll();
        return equipamentos.stream()
                            .map(equipamento -> new EquipamentoDTO(
                                equipamento.getId(),
                                equipamento.getDescricao(),
                                equipamento.getTipo()
                            ))
                            .collect(Collectors.toList());
    }

    // Buscar equipamento por ID e retornar como DTO
    public EquipamentoDTO getEquipamentoById(int id) throws SQLException {
        Equipamento equipamento = equipamentoRepository.findById(id);
        if (equipamento != null) {
            return new EquipamentoDTO(
                equipamento.getId(),
                equipamento.getDescricao(),
                equipamento.getTipo()
            );
        }
        return null;
    }

    // Criar novo equipamento a partir de DTO
    public void createEquipamento(EquipamentoDTO equipamentoDTO) throws SQLException {
        Equipamento equipamento = new Equipamento(
            equipamentoDTO.getId(),
            equipamentoDTO.getDescricao(),
            equipamentoDTO.getTipo()
        );
        equipamentoRepository.save(equipamento);
    }

    // Atualizar equipamento a partir de DTO
    public void updateEquipamento(EquipamentoDTO equipamentoDTO) throws SQLException {
        Equipamento equipamento = new Equipamento(
            equipamentoDTO.getId(),
            equipamentoDTO.getDescricao(),
            equipamentoDTO.getTipo()
        );
        equipamentoRepository.update(equipamento);
    }

    // Excluir equipamento por ID
    public void deleteEquipamento(int id) throws SQLException {
        equipamentoRepository.delete(id);
    }
}
