package com.sistema.dto;

public class TipoEquipamentoDTO {
    private int id;
    private String descricao;

    // Construtor padrão
    public TipoEquipamentoDTO() {}

    // Construtor com todos os campos
    public TipoEquipamentoDTO(int id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "TipoEquipamentoDTO{" +
                "id=" + id +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
