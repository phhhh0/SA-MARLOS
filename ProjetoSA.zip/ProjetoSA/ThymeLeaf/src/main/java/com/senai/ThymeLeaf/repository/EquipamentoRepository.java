package com.sistema.repository;

import com.sistema.model.Equipamento;
import com.sistema.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipamentoRepository {

    // Buscar todos os equipamentos
    public List<Equipamento> findAll() throws SQLException {
        List<Equipamento> equipamentos = new ArrayList<>();
        String sql = "SELECT * FROM equipamentos";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Equipamento equipamento = new Equipamento();
                equipamento.setId(rs.getInt("id"));
                equipamento.setDescricao(rs.getString("descricao"));
                equipamento.setTipo(rs.getString("tipo"));
                equipamentos.add(equipamento);
            }
        }
        return equipamentos;
    }

    // Buscar equipamento por ID
    public Equipamento findById(int id) throws SQLException {
        String sql = "SELECT * FROM equipamentos WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Equipamento equipamento = new Equipamento();
                    equipamento.setId(rs.getInt("id"));
                    equipamento.setDescricao(rs.getString("descricao"));
                    equipamento.setTipo(rs.getString("tipo"));
                    return equipamento;
                }
            }
        }
        return null;
    }

    // Salvar novo equipamento
    public void save(Equipamento equipamento) throws SQLException {
        String sql = "INSERT INTO equipamentos (descricao, tipo) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, equipamento.getDescricao());
            stmt.setString(2, equipamento.getTipo());
            stmt.executeUpdate();
        }
    }

    // Atualizar equipamento
    public void update(Equipamento equipamento) throws SQLException {
        String sql = "UPDATE equipamentos SET descricao = ?, tipo = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, equipamento.getDescricao());
            stmt.setString(2, equipamento.getTipo());
            stmt.setInt(3, equipamento.getId());
            stmt.executeUpdate();
        }
    }

    // Excluir equipamento
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM equipamentos WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
