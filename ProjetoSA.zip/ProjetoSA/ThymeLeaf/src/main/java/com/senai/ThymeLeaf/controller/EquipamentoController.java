package com.sistema.controller;

import com.sistema.dto.EquipamentoDTO;
import com.sistema.service.EquipamentoService;

import java.sql.SQLException;
import java.util.List;

public class EquipamentoController {
    private final EquipamentoService equipamentoService;

    public EquipamentoController() {
        this.equipamentoService = new EquipamentoService();
    }

    // Listar todos os equipamentos
    public List<EquipamentoDTO> listarEquipamentos() throws SQLException {
        return equipamentoService.getAllEquipamentos();
    }

    // Consultar equipamento por ID
    public EquipamentoDTO consultarEquipamento(int id) throws SQLException {
        return equipamentoService.getEquipamentoById(id);
    }

    // Cadastrar novo equipamento
    public void cadastrarEquipamento(EquipamentoDTO equipamentoDTO) throws SQLException {
        equipamentoService.createEquipamento(equipamentoDTO);
    }

    // Atualizar equipamento
    public void atualizarEquipamento(EquipamentoDTO equipamentoDTO) throws SQLException {
        equipamentoService.updateEquipamento(equipamentoDTO);
    }

    // Excluir equipamento
    public void excluirEquipamento(int id) throws SQLException {
        equipamentoService.deleteEquipamento(id);
    }
}
