package com.sistema.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    // URL do banco de dados
    private static final String URL = "jdbc:mysql://localhost:3306/nome_do_banco?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";  // Usuário do MySQL
    private static final String PASSWORD = "sua_senha";  // Senha do MySQL

    // Método para obter a conexão
    public static Connection getConnection() throws SQLException {
        try {
            // Registrar o driver JDBC (não é mais necessário em versões recentes)
            // Class.forName("com.mysql.cj.jdbc.Driver");  // Somente para versões mais antigas
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new SQLException("Erro ao conectar com o banco de dados: " + e.getMessage());
        }
    }
}
