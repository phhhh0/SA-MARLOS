package com.sistema.controller;

import com.senai.ThymeLeaf.model.Usuario;
import com.senai.ThymeLeaf.service.UsuarioService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class UsuarioController extends HttpServlet {
    private final UsuarioService usuarioService;

    public UsuarioController() {
        this.usuarioService = new UsuarioService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "listar";
        }

        switch (action) {
            case "listar" -> listarUsuarios(request, response);
            case "cadastro" -> request.getRequestDispatcher("/cadastro_usuario.jsp").forward(request, response);
            case "visualizar" -> visualizarUsuario(request, response);
            case "atualizar" -> editarUsuario(request, response);
            case "excluir" -> excluirUsuario(request, response);
            default -> listarUsuarios(request, response);
        }
    }

    private void listarUsuarios(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<Usuario> usuarios = usuarioService.getAllUsuarios();
            request.setAttribute("usuarios", usuarios);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (SQLException e) {
        }
    }

    private void visualizarUsuario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            request.setAttribute("usuario", usuario);
            request.getRequestDispatcher("/visualizar_usuario.jsp").forward(request, response);
        } catch (SQLException e) {
        }
    }

    private void editarUsuario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            request.setAttribute("usuario", usuario);
            request.getRequestDispatcher("/editar_usuario.jsp").forward(request, response);
        } catch (SQLException e) {
        }
    }

    private void excluirUsuario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            usuarioService.deleteUsuario(id);
            response.sendRedirect("UsuarioController?action=listar");
        } catch (SQLException e) {
        }
    }
}
