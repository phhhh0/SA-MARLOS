package com.sistema.model;

public class TipoEquipamento {
    private int id;
    private String descricao;

    // Construtor padrão
    public TipoEquipamento() {}

    // Construtor com todos os campos
    public TipoEquipamento(int id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "TipoEquipamento{" +
                "id=" + id +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
