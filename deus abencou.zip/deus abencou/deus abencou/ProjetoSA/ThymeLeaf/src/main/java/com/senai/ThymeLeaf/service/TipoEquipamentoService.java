package com.sistema.service;

import com.sistema.dto.TipoEquipamentoDTO;
import com.sistema.model.TipoEquipamento;
import com.sistema.repository.TipoEquipamentoRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class TipoEquipamentoService {
    private final TipoEquipamentoRepository tipoEquipamentoRepository;

    public TipoEquipamentoService() {
        this.tipoEquipamentoRepository = new TipoEquipamentoRepository();
    }

    // Listar todos os tipos de equipamentos
    public List<TipoEquipamentoDTO> getAllTiposEquipamento() throws SQLException {
        List<TipoEquipamento> tiposEquipamento = tipoEquipamentoRepository.findAll();
        return tiposEquipamento.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // Buscar tipo de equipamento por ID
    public TipoEquipamentoDTO getTipoEquipamentoById(int id) throws SQLException {
        TipoEquipamento tipoEquipamento = tipoEquipamentoRepository.findById(id);
        return tipoEquipamento != null ? convertToDTO(tipoEquipamento) : null;
    }

    // Salvar novo tipo de equipamento
    public void createTipoEquipamento(TipoEquipamentoDTO tipoEquipamentoDTO) throws SQLException {
        TipoEquipamento tipoEquipamento = convertToModel(tipoEquipamentoDTO);
        tipoEquipamentoRepository.save(tipoEquipamento);
    }

    // Atualizar tipo de equipamento
    public void updateTipoEquipamento(TipoEquipamentoDTO tipoEquipamentoDTO) throws SQLException {
        TipoEquipamento tipoEquipamento = convertToModel(tipoEquipamentoDTO);
        tipoEquipamentoRepository.update(tipoEquipamento);
    }

    // Excluir tipo de equipamento
    public void deleteTipoEquipamento(int id) throws SQLException {
        tipoEquipamentoRepository.delete(id);
    }

    // Converter de DTO para Model
    private TipoEquipamento convertToModel(TipoEquipamentoDTO dto) {
        return new TipoEquipamento(dto.getId(), dto.getDescricao());
    }

    // Converter de Model para DTO
    private TipoEquipamentoDTO convertToDTO(TipoEquipamento model) {
        return new TipoEquipamentoDTO(model.getId(), model.getDescricao());
    }
}
