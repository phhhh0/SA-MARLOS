package com.sistema.dto;

import java.util.Date;

public class EmprestimoDTO {
    private int id;
    private int colaboradorId;
    private int equipamentoId;
    private Date data;
    private Date devolucao;

    // Construtor padrão
    public EmprestimoDTO() {}

    // Construtor com todos os campos
    public EmprestimoDTO(int id, int colaboradorId, int equipamentoId, Date data, Date devolucao) {
        this.id = id;
        this.colaboradorId = colaboradorId;
        this.equipamentoId = equipamentoId;
        this.data = data;
        this.devolucao = devolucao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getColaboradorId() {
        return colaboradorId;
    }

    public void setColaboradorId(int colaboradorId) {
        this.colaboradorId = colaboradorId;
    }

    public int getEquipamentoId() {
        return equipamentoId;
    }

    public void setEquipamentoId(int equipamentoId) {
        this.equipamentoId = equipamentoId;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Date getDevolucao() {
        return devolucao;
    }

    public void setDevolucao(Date devolucao) {
        this.devolucao = devolucao;
    }

    @Override
    public String toString() {
        return "EmprestimoDTO{" +
                "id=" + id +
                ", colaboradorId=" + colaboradorId +
                ", equipamentoId=" + equipamentoId +
                ", data=" + data +
                ", devolucao=" + devolucao +
                '}';
    }
}
