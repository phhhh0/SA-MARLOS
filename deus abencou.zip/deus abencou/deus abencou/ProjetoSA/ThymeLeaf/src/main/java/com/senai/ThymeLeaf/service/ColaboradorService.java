package com.sistema.service;

import com.sistema.model.Colaborador;
import com.sistema.dto.ColaboradorDTO;
import com.sistema.repository.ColaboradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ColaboradorService {

    @Autowired
    private ColaboradorRepository colaboradorRepository;

    // Listar todos os colaboradores
    public List<ColaboradorDTO> listarColaboradores() {
        List<Colaborador> colaboradores = colaboradorRepository.findAll();
        return colaboradores.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // Salvar novo colaborador
    public ColaboradorDTO salvarColaborador(ColaboradorDTO colaboradorDTO) {
        Colaborador colaborador = convertToEntity(colaboradorDTO);
        colaborador = colaboradorRepository.save(colaborador);
        return convertToDTO(colaborador);
    }

    // Consultar colaborador por ID
    public ColaboradorDTO consultarColaborador(Integer id) {
        Colaborador colaborador = colaboradorRepository.findById(id).orElseThrow(() -> new RuntimeException("Colaborador não encontrado"));
        return convertToDTO(colaborador);
    }

    // Atualizar colaborador
    public ColaboradorDTO atualizarColaborador(Integer id, ColaboradorDTO colaboradorDTO) {
        Colaborador colaborador = colaboradorRepository.findById(id).orElseThrow(() -> new RuntimeException("Colaborador não encontrado"));
        colaborador.setNome(colaboradorDTO.getNome());
        colaborador.setEmail(colaboradorDTO.getEmail());
        colaborador.setFuncao(colaboradorDTO.getFuncao());
        colaborador.setNascimento(colaboradorDTO.getNascimento());
        colaborador = colaboradorRepository.save(colaborador);
        return convertToDTO(colaborador);
    }

    // Excluir colaborador
    public void excluirColaborador(Integer id) {
        colaboradorRepository.deleteById(id);
    }

    // Método para converter de Colaborador (Entidade) para ColaboradorDTO
    private ColaboradorDTO convertToDTO(Colaborador colaborador) {
        ColaboradorDTO dto = new ColaboradorDTO();
        dto.setId(colaborador.getId());
        dto.setNome(colaborador.getNome());
        dto.setEmail(colaborador.getEmail());
        dto.setFuncao(colaborador.getFuncao());
        dto.setNascimento(colaborador.getNascimento());
        return dto;
    }

    // Método para converter de ColaboradorDTO para Colaborador (Entidade)
    private Colaborador convertToEntity(ColaboradorDTO colaboradorDTO) {
        Colaborador colaborador = new Colaborador();
        colaborador.setId(colaboradorDTO.getId());
        colaborador.setNome(colaboradorDTO.getNome());
        colaborador.setEmail(colaboradorDTO.getEmail());
        colaborador.setFuncao(colaboradorDTO.getFuncao());
        colaborador.setNascimento(colaboradorDTO.getNascimento());
        return colaborador;
    }
}
