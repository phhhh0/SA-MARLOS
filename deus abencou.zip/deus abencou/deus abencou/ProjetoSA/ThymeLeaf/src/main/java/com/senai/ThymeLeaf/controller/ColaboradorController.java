package com.sistema.controller;

import com.sistema.model.Colaborador;
import com.sistema.dto.ColaboradorDTO;
import com.sistema.service.ColaboradorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/colaboradores")
public class ColaboradorController {

    @Autowired
    private ColaboradorService colaboradorService;

    // Listar todos os colaboradores
    @GetMapping
    public ResponseEntity<List<ColaboradorDTO>> listarColaboradores() {
        List<ColaboradorDTO> colaboradores = colaboradorService.listarColaboradores();
        return ResponseEntity.ok(colaboradores);
    }

    // Criar um novo colaborador
    @PostMapping
    public ResponseEntity<ColaboradorDTO> criarColaborador(@RequestBody ColaboradorDTO colaboradorDTO) {
        ColaboradorDTO novoColaborador = colaboradorService.salvarColaborador(colaboradorDTO);
        return new ResponseEntity<>(novoColaborador, HttpStatus.CREATED);
    }

    // Consultar colaborador por ID
    @GetMapping("/{id}")
    public ResponseEntity<ColaboradorDTO> consultarColaborador(@PathVariable Integer id) {
        ColaboradorDTO colaborador = colaboradorService.consultarColaborador(id);
        return ResponseEntity.ok(colaborador);
    }

    // Atualizar colaborador
    @PutMapping("/{id}")
    public ResponseEntity<ColaboradorDTO> atualizarColaborador(@PathVariable Integer id, @RequestBody ColaboradorDTO colaboradorDTO) {
        ColaboradorDTO colaboradorAtualizado = colaboradorService.atualizarColaborador(id, colaboradorDTO);
        return ResponseEntity.ok(colaboradorAtualizado);
    }

    // Excluir colaborador
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirColaborador(@PathVariable Integer id) {
        colaboradorService.excluirColaborador(id);
        return ResponseEntity.noContent().build();
    }
}
