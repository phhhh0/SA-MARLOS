package com.senai.epi.Service; // Certifique-se de que está no pacote correto

import com.senai.ThymeLeaf.dtos.LoginDto;
import com.senai.epi.Dtos.usuarioDto;
import com.senai.epi.Models.UsuarioModel;
import com.senai.epi.Repository.usuarioRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class usuarioService { // Mantendo o nome com minúscula

    @Autowired
    private usuarioRepository repository;

    public boolean validarLogin(LoginDto loginDto) {
        Optional<UsuarioModel> optionalUsuario = repository.findByEmail(loginDto.getEmail());
        return optionalUsuario.isPresent() &&
               optionalUsuario.get().getSenha().equals(loginDto.getSenha());
    }

    public List<usuarioDto> obterListaUsuarios() {
        List<UsuarioModel> listaUsuarioModel = repository.findAll();
        List<usuarioDto> listaUsuario = new ArrayList<>();

        for (UsuarioModel usuario : listaUsuarioModel) {
            usuarioDto usuarioDto = new usuarioDto();
            usuarioDto.setId(usuario.getId());
            usuarioDto.setNome(usuario.getNome());
            usuarioDto.setEmail(usuario.getEmail());
            listaUsuario.add(usuarioDto);
        }

        return listaUsuario;
    }

    public boolean cadastrarUsuario(usuarioDto cadastro) {
        if (repository.findByEmail(cadastro.getEmail()).isPresent()) {
            return false;
        }

        UsuarioModel usuario = new UsuarioModel();
        usuario.setNome(cadastro.getNome());
        usuario.setEmail(cadastro.getEmail());
        usuario.setSenha(cadastro.getSenha());
        repository.save(usuario);

        return true;
    }

    public boolean excluirUsuario(Long id) {
        Optional<UsuarioModel> optionalUsuario = repository.findById(id);
        if (optionalUsuario.isEmpty()) {
            return false;
        }

        repository.delete(optionalUsuario.get());
        return true;
    }

    public usuarioDto obterUsuario(Long id) {
        Optional<UsuarioModel> optionalUsuario = repository.findById(id);
        if (optionalUsuario.isEmpty()) {
            return new usuarioDto(0L, "", "");
        }

        UsuarioModel usuario = optionalUsuario.get();
        return new usuarioDto(usuario.getId(), usuario.getNome(), usuario.getEmail());
    }

    public boolean atualizarUsuario(Long id, usuarioDto dados) {
        Optional<UsuarioModel> optionalUsuario = repository.findById(id);
        if (optionalUsuario.isEmpty()) {
            return false;
        }

        UsuarioModel usuario = optionalUsuario.get();
        usuario.setNome(dados.getNome());
        usuario.setEmail(dados.getEmail());
        usuario.setSenha(dados.getSenha());
        repository.save(usuario);

        return true;
    }
}
