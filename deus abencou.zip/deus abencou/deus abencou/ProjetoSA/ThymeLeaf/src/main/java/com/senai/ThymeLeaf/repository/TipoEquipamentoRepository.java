package com.sistema.repository;

import com.sistema.model.TipoEquipamento;
import com.sistema.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoEquipamentoRepository {

    // Buscar todos os tipos de equipamentos
    public List<TipoEquipamento> findAll() throws SQLException {
        List<TipoEquipamento> tiposEquipamento = new ArrayList<>();
        String sql = "SELECT * FROM tipo_equipamento";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                TipoEquipamento tipo = new TipoEquipamento();
                tipo.setId(rs.getInt("id"));
                tipo.setDescricao(rs.getString("descricao"));
                tiposEquipamento.add(tipo);
            }
        }
        return tiposEquipamento;
    }

    // Buscar tipo de equipamento por ID
    public TipoEquipamento findById(int id) throws SQLException {
        String sql = "SELECT * FROM tipo_equipamento WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    TipoEquipamento tipo = new TipoEquipamento();
                    tipo.setId(rs.getInt("id"));
                    tipo.setDescricao(rs.getString("descricao"));
                    return tipo;
                }
            }
        }
        return null;
    }

    // Salvar novo tipo de equipamento
    public void save(TipoEquipamento tipo) throws SQLException {
        String sql = "INSERT INTO tipo_equipamento (descricao) VALUES (?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tipo.getDescricao());
            stmt.executeUpdate();
        }
    }

    // Atualizar tipo de equipamento
    public void update(TipoEquipamento tipo) throws SQLException {
        String sql = "UPDATE tipo_equipamento SET descricao = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tipo.getDescricao());
            stmt.setInt(2, tipo.getId());
            stmt.executeUpdate();
        }
    }

    // Excluir tipo de equipamento
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM tipo_equipamento WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
