package com.sistema.repository;

import com.sistema.model.Colaborador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColaboradorRepository extends JpaRepository<Colaborador, Integer> {

    // Aqui você pode adicionar consultas customizadas, se necessário
    Colaborador findByEmail(String email);

}
