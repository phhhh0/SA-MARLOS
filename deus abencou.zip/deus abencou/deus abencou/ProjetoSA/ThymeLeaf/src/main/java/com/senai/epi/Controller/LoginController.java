package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.LoginDto;
import com.senai.epi.Service.usuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping() 
public class LoginController {

    @Autowired
    private usuarioService usuarioService; // Nome da classe com letra minúscula

    @GetMapping("/login")
    public String exibirLogin(Model model){
        LoginDto loginDto = new LoginDto();
        model.addAttribute("loginDto", loginDto);
        return "login"; // Retorna o template de login
    }

    @PostMapping("/login")
    public String realizarLogin(@ModelAttribute("loginDto") LoginDto loginDto){           
        boolean acesso = usuarioService.validarLogin(loginDto); // Chamando o serviço

        if(acesso){
            return "redirect:/home"; // Redireciona para a página home
        }

        return "redirect:/login?erro"; // Caso o login falhe, retorna erro
    } 

    @PostMapping("/logout")
    public String realizarLogout(){
        return "redirect:/login?logout"; // Redireciona para o login após logout
    }
}
