package com.sistema.service;

import com.sistema.dto.EmprestimoDTO;
import com.sistema.model.Emprestimo;
import com.sistema.repository.EmprestimoRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class EmprestimoService {
    private final EmprestimoRepository emprestimoRepository;

    public EmprestimoService() {
        this.emprestimoRepository = new EmprestimoRepository();
    }

    // Listar todos os empréstimos
    public List<EmprestimoDTO> getAllEmprestimos() throws SQLException {
        List<Emprestimo> emprestimos = emprestimoRepository.findAll();
        return emprestimos.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // Buscar empréstimo por ID
    public EmprestimoDTO getEmprestimoById(int id) throws SQLException {
        Emprestimo emprestimo = emprestimoRepository.findById(id);
        return emprestimo != null ? convertToDTO(emprestimo) : null;
    }

    // Salvar novo empréstimo
    public void createEmprestimo(EmprestimoDTO emprestimoDTO) throws SQLException {
        Emprestimo emprestimo = convertToModel(emprestimoDTO);
        emprestimoRepository.save(emprestimo);
    }

    // Atualizar empréstimo
    public void updateEmprestimo(EmprestimoDTO emprestimoDTO) throws SQLException {
        Emprestimo emprestimo = convertToModel(emprestimoDTO);
        emprestimoRepository.update(emprestimo);
    }

    // Excluir empréstimo
    public void deleteEmprestimo(int id) throws SQLException {
        emprestimoRepository.delete(id);
    }

    // Converter de DTO para Model
    private Emprestimo convertToModel(EmprestimoDTO dto) {
        return new Emprestimo(dto.getId(), dto.getColaboradorId(), dto.getEquipamentoId(), dto.getData(), dto.getDevolucao());
    }

    // Converter de Model para DTO
    private EmprestimoDTO convertToDTO(Emprestimo model) {
        return new EmprestimoDTO(model.getId(), model.getColaboradorId(), model.getEquipamentoId(), model.getData(), model.getDevolucao());
    }
}
