package com.sistema.repository;

import com.sistema.model.Emprestimo;
import com.sistema.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmprestimoRepository {

    // Buscar todos os empréstimos
    public List<Emprestimo> findAll() throws SQLException {
        List<Emprestimo> emprestimos = new ArrayList<>();
        String sql = "SELECT * FROM emprestimos";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Emprestimo emprestimo = new Emprestimo();
                emprestimo.setId(rs.getInt("id"));
                emprestimo.setColaboradorId(rs.getInt("colaborador_id"));
                emprestimo.setEquipamentoId(rs.getInt("equipamento_id"));
                emprestimo.setData(rs.getDate("data"));
                emprestimo.setDevolucao(rs.getDate("devolucao"));
                emprestimos.add(emprestimo);
            }
        }
        return emprestimos;
    }

    // Buscar empréstimo por ID
    public Emprestimo findById(int id) throws SQLException {
        String sql = "SELECT * FROM emprestimos WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Emprestimo emprestimo = new Emprestimo();
                    emprestimo.setId(rs.getInt("id"));
                    emprestimo.setColaboradorId(rs.getInt("colaborador_id"));
                    emprestimo.setEquipamentoId(rs.getInt("equipamento_id"));
                    emprestimo.setData(rs.getDate("data"));
                    emprestimo.setDevolucao(rs.getDate("devolucao"));
                    return emprestimo;
                }
            }
        }
        return null;
    }

    // Salvar novo empréstimo
    public void save(Emprestimo emprestimo) throws SQLException {
        String sql = "INSERT INTO emprestimos (colaborador_id, equipamento_id, data, devolucao) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, emprestimo.getColaboradorId());
            stmt.setInt(2, emprestimo.getEquipamentoId());
            stmt.setDate(3, new java.sql.Date(emprestimo.getData().getTime()));
            stmt.setDate(4, new java.sql.Date(emprestimo.getDevolucao().getTime()));
            stmt.executeUpdate();
        }
    }

    // Atualizar empréstimo
    public void update(Emprestimo emprestimo) throws SQLException {
        String sql = "UPDATE emprestimos SET colaborador_id = ?, equipamento_id = ?, data = ?, devolucao = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, emprestimo.getColaboradorId());
            stmt.setInt(2, emprestimo.getEquipamentoId());
            stmt.setDate(3, new java.sql.Date(emprestimo.getData().getTime()));
            stmt.setDate(4, new java.sql.Date(emprestimo.getDevolucao().getTime()));
            stmt.setInt(5, emprestimo.getId());
            stmt.executeUpdate();
        }
    }

    // Excluir empréstimo
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM emprestimos WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
