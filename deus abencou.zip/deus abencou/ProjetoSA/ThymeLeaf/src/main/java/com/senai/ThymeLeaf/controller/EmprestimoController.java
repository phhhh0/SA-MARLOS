package com.sistema.controller;

import com.sistema.dto.EmprestimoDTO;
import com.sistema.service.EmprestimoService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class EmprestimoController {

    private final EmprestimoService emprestimoService;

    public EmprestimoController() {
        this.emprestimoService = new EmprestimoService();
    }

    // Listar todos os empréstimos
    public void listEmprestimos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<EmprestimoDTO> emprestimos = emprestimoService.getAllEmprestimos();
            request.setAttribute("emprestimos", emprestimos);
            request.getRequestDispatcher("/listEmprestimos.jsp").forward(request, response);
        } catch (ServletException | IOException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao listar empréstimos");
        }
    }

    // Consultar empréstimo por ID
    public void viewEmprestimo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            EmprestimoDTO emprestimo = emprestimoService.getEmprestimoById(id);
            request.setAttribute("emprestimo", emprestimo);
            request.getRequestDispatcher("/viewEmprestimo.jsp").forward(request, response);
        } catch (ServletException | IOException | NumberFormatException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao consultar empréstimo");
        }
    }

    // Criar novo empréstimo
    public void createEmprestimo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int colaboradorId = Integer.parseInt(request.getParameter("colaboradorId"));
            int equipamentoId = Integer.parseInt(request.getParameter("equipamentoId"));
            Date data = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("data"));
            Date devolucao = null; // Inicialmente null, pois será definido quando devolvido.

            EmprestimoDTO emprestimoDTO = new EmprestimoDTO(0, colaboradorId, equipamentoId, data, devolucao);
            emprestimoService.createEmprestimo(emprestimoDTO);

            response.sendRedirect("listEmprestimos");
        } catch (IOException | NumberFormatException | SQLException | ParseException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao criar empréstimo");
        }
    }

    // Atualizar empréstimo
    public void updateEmprestimo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            int colaboradorId = Integer.parseInt(request.getParameter("colaboradorId"));
            int equipamentoId = Integer.parseInt(request.getParameter("equipamentoId"));
            Date data = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("data"));
            Date devolucao = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("devolucao"));

            EmprestimoDTO emprestimoDTO = new EmprestimoDTO(id, colaboradorId, equipamentoId, data, devolucao);
            emprestimoService.updateEmprestimo(emprestimoDTO);

            response.sendRedirect("listEmprestimos");
        } catch (IOException | NumberFormatException | SQLException | ParseException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao atualizar empréstimo");
        }
    }

    // Excluir empréstimo
    public void deleteEmprestimo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            emprestimoService.deleteEmprestimo(id);
            response.sendRedirect("listEmprestimos");
        } catch (IOException | NumberFormatException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao excluir empréstimo");
        }
    }
}
