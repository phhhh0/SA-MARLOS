package com.senai.ThymeLeaf.service;

import com.senai.ThymeLeaf.model.Usuario;
import com.senai.ThymeLeaf.repository.UsuarioRepository;

import java.sql.SQLException;
import java.util.List;

public class UsuarioService {
    private final UsuarioRepository usuarioRepository;

    public UsuarioService() {
        this.usuarioRepository = new UsuarioRepository();
    }

    public List<Usuario> getAllUsuarios() throws SQLException {
        return usuarioRepository.findAll();
    }

    public Usuario getUsuarioById(int id) throws SQLException {
        return (Usuario) usuarioRepository.findById(id);
    }

    public void createUsuario(Usuario usuario) throws SQLException {
        usuarioRepository.save(usuario);
    }

    public void updateUsuario(Usuario usuario) throws SQLException {
        usuarioRepository.update(usuario);
    }

    public void deleteUsuario(int id) throws SQLException {
        usuarioRepository.delete(id);
    }
}
