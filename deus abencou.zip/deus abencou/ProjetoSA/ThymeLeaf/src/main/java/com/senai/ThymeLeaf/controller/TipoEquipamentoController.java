package com.sistema.controller;

import com.sistema.dto.TipoEquipamentoDTO;
import com.sistema.service.TipoEquipamentoService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class TipoEquipamentoController {

    private final TipoEquipamentoService tipoEquipamentoService;

    public TipoEquipamentoController() {
        this.tipoEquipamentoService = new TipoEquipamentoService();
    }

    // Listar todos os tipos de equipamentos
    public void listTipoEquipamentos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<TipoEquipamentoDTO> tiposEquipamento = tipoEquipamentoService.getAllTiposEquipamento();
            request.setAttribute("tiposEquipamento", tiposEquipamento);
            request.getRequestDispatcher("/listTipoEquipamento.jsp").forward(request, response);
        } catch (ServletException | IOException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao listar tipos de equipamento");
        }
    }

    // Consultar tipo de equipamento por ID
    public void viewTipoEquipamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            TipoEquipamentoDTO tipoEquipamento = tipoEquipamentoService.getTipoEquipamentoById(id);
            request.setAttribute("tipoEquipamento", tipoEquipamento);
            request.getRequestDispatcher("/viewTipoEquipamento.jsp").forward(request, response);
        } catch (ServletException | IOException | NumberFormatException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao consultar tipo de equipamento");
        }
    }

    // Criar novo tipo de equipamento
    public void createTipoEquipamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String descricao = request.getParameter("descricao");
            TipoEquipamentoDTO tipoEquipamentoDTO = new TipoEquipamentoDTO(0, descricao);
            tipoEquipamentoService.createTipoEquipamento(tipoEquipamentoDTO);

            response.sendRedirect("listTipoEquipamentos");
        } catch (IOException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao criar tipo de equipamento");
        }
    }

    // Atualizar tipo de equipamento
    public void updateTipoEquipamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String descricao = request.getParameter("descricao");

            TipoEquipamentoDTO tipoEquipamentoDTO = new TipoEquipamentoDTO(id, descricao);
            tipoEquipamentoService.updateTipoEquipamento(tipoEquipamentoDTO);

            response.sendRedirect("listTipoEquipamentos");
        } catch (IOException | NumberFormatException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao atualizar tipo de equipamento");
        }
    }

    // Excluir tipo de equipamento
    public void deleteTipoEquipamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            tipoEquipamentoService.deleteTipoEquipamento(id);
            response.sendRedirect("listTipoEquipamentos");
        } catch (IOException | NumberFormatException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao excluir tipo de equipamento");
        }
    }
}
