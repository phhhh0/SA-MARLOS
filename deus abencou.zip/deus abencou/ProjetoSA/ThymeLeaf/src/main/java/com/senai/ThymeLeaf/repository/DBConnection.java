package com.sistema.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    // URL do banco de dados
    private static final String URL = "jdbc:mysql://localhost:3306/logindb?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";  // Usuá rio do MySQL
    private static final String PASSWORD = "";  // Senha do MySQL

    // Método para obter a conexão
    public static Connection getConnection() throws SQLException {
        try {
            // Registrar o driver JDBC (não é mais necessário em versões recentes)
            // Class.forName("com.mysql.cj.jdbc.Driver");  // Somente para versões mais antigas
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new SQLException("Erro ao conectar com o banco de dados: " + e.getMessage());
        }
    }
}
